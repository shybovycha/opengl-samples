ikpMP3 is a plugin for irrKlang.
Copyright (C) 2002-2007 Nikolaus Gebhardt
Part of the code for this plugin for irrKlang is based on:
 MP3 input for Audiere by Matt Campbell <mattcampbell@pobox.com>, based on
  libavcodec from ffmpeg (http://ffmpeg.sourceforge.net/). 
 See license.txt for license details of this plugin.
 
