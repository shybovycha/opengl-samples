var searchData=
[
  ['get_20information_20out_20of_20xml_280',['Get information out of XML',['../_example_3.html',1,'']]]
];
